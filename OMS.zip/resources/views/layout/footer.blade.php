<div class="text-center">
    2016 &copy; Tech Cloud Ltd. | Designed & Developed by <a target="_blank" href="http://techcloudltd.com/">Tech Cloud Ltd.</a>
    <a href="#" class="go-top">
        <i class="fa fa-angle-up"></i>
    </a>
</div>
