<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keyword" content="">
    <?php echo $__env->make('css.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

<section id="container" >
    <!--header start-->
<?php echo $__env->make('Navigation.topmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--header end-->
    <!--sidebar start-->
    <aside>
        <div id="sidebar"  class="nav-collapse ">
            <!-- sidebar menu start-->
            <ul class="sidebar-menu" id="nav-accordion">
                <?php echo $__env->make('Navigation.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>
            <!-- sidebar menu end-->
        </div>
    </aside>
    <!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">

            <div id="fullrow" class="row">
                <div class="panel-body">
                    <div class="col-sm-12 message_section">
                        <div class="row">
                            <div class="new_message_head">
                                <div class="pull-left"><button>Message System</button></div>
                            </div><!--new_message_head-->
                            <div id="">

                                <div  id="newmsg" class="chat_area">
                                    <ul class="list-unstyled">
                                        <?php if(session('user-type')=='Admin'): ?>
                                            <?php $__currentLoopData = $client_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($s->sender == $client1): ?>
                                                    <li class="left clearfix">
                     <span style="color: red" class=" pull-left"><?php echo e($client1); ?>

                     </span>
                                                        <div class="chat-body1 clearfix">
                                                            <div class="chat_time pull-left"><?php echo e($s->inserted_time); ?></div><br>
                                                            <p class=" pull-left"><?php echo e($s->sms); ?></p>

                                                        </div>
                                                    </li>
                                                <?php elseif($s->sender =="Admin"): ?>

                                                    <li class="left clearfix admin_chat">
                     <span style="color: blue" class=" pull-right">Admin
                     </span>
                                                        <div class="chat-body1 clearfix">
                                                            <div class="chat_time pull-right"><?php echo e($s->inserted_time); ?></div><br>
                                                            <p class="chat_time pull-right"><?php echo e($s->sms); ?></p>

                                                        </div>
                                                    </li>

                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php elseif(session('user-type')=='User'): ?>
                                            <?php $__currentLoopData = $client_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($s->sender == "Admin"): ?>
                                                    <li class="left clearfix">
                     <span style="color: red" class="chat-img1 pull-left">Admin
                     </span>

                                                        <div class="chat-body1 clearfix ">
                                                            <div ><?php echo e($s->inserted_time); ?></div><br>
                                                            <p ><?php echo e($s->sms); ?></p>

                                                        </div>
                                                    </li>
                                                <?php elseif($s->sender ==$client1): ?>

                                                    <li class="left clearfix admin_chat">
                     <span style="color: blue"class="chat-img1 pull-right"><?php echo e($client1); ?>

                     </span>

                                                        <div class="chat-body1 clearfix">
                                                            <div class="pull-right"><?php echo e($s->inserted_time); ?></div><br>
                                                            <p class="pull-right"><?php echo e($s->sms); ?></p>

                                                        </div>
                                                    </li>

                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>

                                    </ul>

                                    <div id="txtHint" ></div>
                                </div>
                                <!--chat_area-->
                            </div>

                            <form method="post" id="smsbox" action="<?php echo e(route('insersms',['client1'=>$client1])); ?>" onsubmit="return validateForm()">
                                <?php echo e(csrf_field()); ?>

                                <div class="message_write">
                                    <textarea class="form-control" id="sms" name="sms" placeholder="type a message"></textarea>

                                    <div class="chat_bottom">
                                        
                                        
                                        <input class="pull-right btn btn-success"type="submit" value="Send">
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div> <!--message_section-->


                </div>
            </div>
            <!--state overview end-->
        </section>
    </section>
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
        <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </footer>
    <!--footer end-->
</section>

<?php echo $__env->make('js.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php
$type=session('status');
if ($type == 'Admin'){
    $sms1 = DB::select( DB::raw("SELECT COUNT(*) AS total  FROM `message` WHERE `sender` ='$client1' AND `receiver`='Admin' AND `status`='unseen' ") );
    foreach ($sms1 as $count){
        echo $totalsmsforadmin = $count->total;
    }
}
elseif(session('status') == 'User'){
    $sms1 = DB::select( DB::raw("SELECT COUNT(*) AS total  FROM `message` WHERE `sender` ='Admin' AND `receiver`='$client1' AND `status`='unseen' ") );
    foreach ($sms1 as $count){
        echo $totalsmsforadmin = $count->total;
    }
}
?>

<script>
    var old_msg = "<?php echo $totalsmsforadmin?>";
    var client = "<?php echo $client1?>";
    var type = "<?php echo $type?>";
    var old_amount = parseInt(old_msg);
    var count =0;
    setInterval(function(){
        if (type =="Admin") {
            $.ajax({
                type : 'get',
                url:'<?php echo e('/getlivemsg'); ?>',
                data: {'sender':client,'reciever':'Admin'},
                cache: false,
                success : function(datan){
                    if (parseFloat(datan) > old_amount) {
                        $.ajax({
                            type : 'get',
                            url:'<?php echo e('/getlivemsgdata'); ?>',
                            data: {'sender':client,'reciever':'Admin'},
                            cache: false,
                            success : function(datas) {
                                $('#txtHint').html(datas);
                                //$("#txtHint").show();
                                //alert('it works'); //ajax response successful alert box shows
                                //should hide a div element
                                $( "#newmsg" ).scrollTop($("#newmsg")[0].scrollHeight);
                                //alert(datas);
                            }
                        });
                        //scroll();
                        old_amount =datan;
                    }else {
                        //$("#newmsg").html(result).scrollTop(1000);
                        //alert(datan);
                        // document.getElementById("txtHint").style.display= "none";
                    }
                }
            });
        }
        else{
            $.ajax({
                type : 'get',
                url:'<?php echo e('/getlivemsg'); ?>',
                data: {'sender':'Admin','reciever':client},
                cache: false,
                success : function(datan){
                    if (parseFloat(datan) > old_amount) {
                        $.ajax({
                            type : 'get',
                            url:'<?php echo e('/getlivemsgdata'); ?>',
                            data: {'sender':'Admin','reciever':client},
                            cache: false,
                            success : function(datas) {
                                $('#txtHint').html(datas);
                                $( "#newmsg" ).scrollTop($("#newmsg")[0].scrollHeight);
                            }
                        });
                        old_amount =datan;
                    }else {
                        //$("#newmsg").html(result).scrollTop(1000);
                        //scroll();
                        //    document.getElementById("txtHint").style.display= "none";
                    }
                }
            });
        }
    },600);
</script>


<script>
    $( "#newmsg" ).scrollTop($("#newmsg")[0].scrollHeight);
    $( "#sms" ).focus();
</script>

<script>
    function validateForm() {
        var x = document.forms["smsbox"]["sms"].value;
        if (x == "") {
            alert("Please write some text first!!");
            return false;
        }
        else {
            return true;
        }
    }
</script>

</body>
</html>
