<?php
namespace App;
use Illuminate\Support\Facades\DB;
//include("php/connection.php");
//if($_SESSION['order']== NULL)
//{
//
//    echo "<script type=\"text/javascript\">
//        alert(\"Login First\");
//        window.location=\"../index.php\";
//        </script>";
//}
        ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php
if (session('order')==NULL){
    echo "<script type=\"text/javascript\">
        alert(\"Login First\");
        window.location=\"{{url('/')}}\";
        </script>";
}
/*----------------------------------------------------------------------------------------------------------------*/
//else if($_SESSION['order']!= null && $_SESSION['status']=="User")
//{
elseif (session('order')!= null && session('status')== "User"){
$clientname =session('order');
$sms = DB::select( DB::raw("SELECT COUNT(*) AS total  FROM `message` WHERE `receiver` ='$clientname' AND `status`='unseen' ") );

?>
<?php $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $totalforuser = $count->total ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<li>
    <a href="<?php echo e(url('/Home')); ?>">
        <i class="fa fa-dashboard"></i>
        <span>Dashboard</span>
    </a>
</li>
<li>
    <a  href="<?php echo e(route('usernewjobrequest')); ?>">
        <i class="fa fa-briefcase"></i>
        <span>New Job Request</span>
    </a>
</li>
<li class="sub-menu">
    <a href="javascript:;" >
        <i class="fa fa-laptop"></i>
        <span>Work</span>
    </a>
    <ul class="sub">
        <li><a  href="<?php echo e(route('pendingjob_user')); ?>">Pending</a></li>
        <li><a  href="<?php echo e(route('ongoingjob_user')); ?>">On Going</a></li>
        <li><a  href="<?php echo e(route('finshedjob_user')); ?>">Done</a></li>

    </ul>
</li>
<li class="sub-menu">
    
    
    
    

    <a href="<?php echo e(route('usersms',['client'=>session('order')])); ?>"  >
        <i class="fa fa-comment"></i>
        <span>Message</span><span id="output1" style="color:#FFF;;margin: 1px;font-size: 13px;"></span>
    </a>

</li>
<script>
    var old_countsu = "<?php echo $totalforuser?>";
    var old_countu = parseInt(old_countsu);
    var countu =0;
    setInterval(function(){
        $.ajax({
            type : 'get',
            url:'<?php echo e('/getNotifUser'); ?>',
            cache: false,
            success : function(datan){
                if (parseFloat(datan) > old_countu) {
                    countu=countu+1;
                    $('#output1').html(" ("+countu+")"),
                        old_countu = datan;
                }else {
                    $('#output1').html(" ("+old_countu+")")
                }
            }
        });
    },600);
</script>
<?php
}
/*----------------------------------------------------------------------------------------------------------------*/
//else if($_SESSION['order']!= null && $_SESSION['status']=="Admin")
//{
elseif(session('order')!=null && session('status')=="Admin"){
$sms = DB::select( DB::raw("SELECT COUNT(*) AS total  FROM `message` WHERE `sender` !='Admin' AND `status`='unseen' ") );
?>

<?php $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $totalforadmin = $count->total ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<li>
    <a href="<?php echo e('/Home'); ?>">
        <i class="fa fa-dashboard"></i>
        <span>Dashboard</span>
    </a>
</li>
<li>
    <a  href="<?php echo e(route('adminnewjobrequest')); ?>">
        <i class="fa fa-briefcase"></i>
        <span>New Job Request</span>
    </a>
</li>
<li>
    <a  href="<?php echo e(route('newuserrequest')); ?>">
        <i class="fa fa-user"></i>
        <span>New User Request</span>
    </a>
</li>
<li class="sub-menu">
    <a href="javascript:;" >
        <i class="fa fa-laptop"></i>
        <span>Work</span>
    </a>
    <ul class="sub">
        <li><a  href="<?php echo e(route('ongoingjob')); ?>">On Going</a></li>
        <li><a  href="<?php echo e(route('finshedjob')); ?>">Done</a></li>
    </ul>
</li>
<!--<li>
    <a  href="JobInfo.php">
        <i class="fa fa-spinner"></i>
        <span>Work</span>
    </a>
</li>-->
<li>
    <a  href="<?php echo e(route('clintinfo')); ?>">
        <i class="fa fa-users"></i>
        <span>Clients Info</span>
    </a>
</li>

<!--<li class="sub-menu">
    <a href="javascript:;" >
        <i class="fa fa-laptop"></i>
        <span>Report</span>
    </a>
    <ul class="sub">
        <li><a  href="AllocationHistory.php">Allocation History</a></li>
        <li><a  href="SendReport.php">SMS Delivery Status</a></li>
        <li><a  href="Allocation&Payments.php">Allocation & Payment</a></li>
    </ul>
</li> -->

<li class="sub-menu">
    <a href="javascript:;" >
        <i class="fa fa-laptop"></i>
        <span>Others</span>
    </a>
    <ul class="sub">

        <li><a  href="<?php echo e('/Service'); ?>">Service Information</a></li>
        <li><a  href="<?php echo e(route('passchange')); ?>">Password Change</a></li>
    </ul>
</li>

<li class="sub-menu">
    <a href="<?php echo e(route('adminsms')); ?>" >
        <i class="fa fa-comment"></i>
        <span>Message</span><span id="output2" style="color:#FFF;;margin: 1px;font-size: 13px;"></span>
    </a>

</li>

<script>
    var old_counts = "<?php echo $totalforadmin?>";
    var old_count = parseInt(old_counts);
    var count =0;
    setInterval(function(){
        $.ajax({
            type : 'get',
            url:'<?php echo e('/getNotifAdmin'); ?>',
            cache: false,
            success : function(datan){
                if (parseFloat(datan) > old_count) {
                    count=count+1;
                    $('#output2').html(" ("+count+")"),
                        old_count = datan;
                }else {
                    $('#output2').html(" ("+old_count+")")
                }
            }
        });
    },600);
</script>

<?php
}
?>