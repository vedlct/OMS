
<form method="post" action="<?php echo e(route('insertjobcomment',['job_id'=>$job_id])); ?>">
    <?php echo e(csrf_field()); ?>


    <div class="form-group" style="overflow:auto;width: 100%;height: 200px">
        <?php $__currentLoopData = $jobcomment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($comment->sender =='Admin'): ?>
                <div align="left"><span style="color: red">Admin</span>
            <pre style="border: none"><?php echo $comment->sms ?></pre><hr>
                </div>
            <?php else: ?>

            <div align="right"><span style="color: blue">User</span>
                <pre style="border: none"><?php echo $comment->sms ?></pre><hr>
            </div>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <div class="form-group">
        <div class="message_write">
            <textarea class="form-control" name="sms" placeholder="type message"></textarea>

            <div class="chat_bottom"><a href="#" class="pull-left upload_btn"><i class="fa fa-cloud-upload" aria-hidden="true"></i>
                    Add Files</a>

            </div>

        </div>
    </div>
    <div class="form-group" align="right">
        <button type="submit" class="btn btn-success ">Submit</button>
    </div>
</form>

