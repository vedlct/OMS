

<?php $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s->sender); ?>:<?php echo e($s->sms); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<html>

<form method="post" action="/inputsms/<?php echo e($client1); ?>">
    <?php echo e(csrf_field()); ?>

<textarea name="sms"></textarea><br>
    <input type="submit">
</form>
</html>