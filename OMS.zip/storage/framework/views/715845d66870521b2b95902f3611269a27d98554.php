
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keyword" content="">
    <?php echo $__env->make('css.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
<section id="container" >
    <!--header start-->
<?php echo $__env->make('Navigation.topmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--header end-->
    <!--sidebar start-->
    <aside>
        <div id="sidebar"  class="nav-collapse ">
            <!-- sidebar menu start-->
            <ul class="sidebar-menu" id="nav-accordion">
                <?php echo $__env->make('Navigation.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>
            <!-- sidebar menu end-->
        </div>
    </aside>
    <!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <!--state overview start-->
            <div class="row">
                <div class="col-lg-3">
                </div>
                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div  class="panel-heading">
                            User Information
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">

                                <?php $__currentLoopData = $profile_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <table width="100%" class="table table-striped table-bordered table-hover">
                                    <tr>
                                        <th colspan="3"><div align="center"><strong><h4>Customer Profile</h4></strong></div></th>
                                    </tr>
                                    <tr>
                                        <td width="32%" rowspan="6"><img src="<?php echo e(url('img/profile_avt.png')); ?>"></td>
                                        <td width="19%">Company Name :</td>
                                        <td width="49%"><?php echo e($profile->company_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Contact Person :</td>

                                        <td><?php echo e($profile->contact_person); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Number :</td>

                                        <td><?php echo e($profile->contact_no); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email :</td>

                                        <td><?php echo e($profile->email); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Website :</td>

                                        <td><?php echo e($profile->webaddress); ?></td>
                                    </tr>
                                    <tr>
                                        <td>User Type :</td>

                                        <td><?php echo e($profile->user_type); ?></td>
                                    </tr>
                                    <tr>
                                        <td width="32%">Address :</td>

                                        <td colspan="2"><?php echo e($profile->address); ?></td>
                                    </tr>
                                </table>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--state overview end-->
        </section>
    </section>
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
        <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>
    <!--footer end-->
</section>

</body>
</html>
<?php echo $__env->make('js.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>