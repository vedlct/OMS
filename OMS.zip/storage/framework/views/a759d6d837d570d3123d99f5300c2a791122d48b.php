<?php $__currentLoopData = $getpass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="post" action="<?php echo e(url('/passchange')); ?>/<?php echo e($pass->user_id); ?>">
    <?php echo e(csrf_field()); ?>

    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <tr>
            <td>Agent Name :</td>
            <td><input type="text" class="form-control" name="aname" id="field"  value="<?php echo e($pass->company_name); ?>" disabled /></td>
        </tr>
        <tr>
            <td>Password :</td>
            <td><input type="password" class="form-control" name="NP" id="field" value="" required/></td>
        </tr>
        <tr>
            <td>Confirm Password :</td>
            <td><input type="password" class="form-control" name="CNP" id="field" value="" required/></td>
        </tr>
        <tr>

        </tr>
        <tr>
            <td colspan="2">
                <div align="center">
                    <input type="submit" name="submit" id="NewPass" value="SAVE" />
                </div>
            </td>
        </tr>
    </table>
</form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>