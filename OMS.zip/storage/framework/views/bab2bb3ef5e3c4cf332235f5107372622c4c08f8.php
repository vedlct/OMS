
<div  class="chat_area">
    <ul class="list-unstyled">
        <?php if(session('user-type')=='Admin'): ?>
            <?php $__currentLoopData = $getlivemsgdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($s->sender == 'Admin'): ?>
                    <li class="left clearfix admin_chat">
                     <span style="color: blue" class=" pull-right">Admin
                     </span>
                        <div class="chat-body1 clearfix">
                            <div class="chat_time pull-right"><?php echo e($s->inserted_time); ?></div><br>
                            <p class="chat_time pull-right"><?php echo e($s->sms); ?></p>

                        </div>
                    </li>
                <?php else: ?>

                    <li class="left clearfix">
                     <span style="color: red" class=" pull-left"><?php echo e($s->sender); ?>

                     </span>
                        <div class="chat-body1 clearfix">
                            <div class="chat_time pull-left"><?php echo e($s->inserted_time); ?></div><br>
                            <p class=" pull-left"><?php echo e($s->sms); ?></p>

                        </div>
                    </li>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(session('user-type')=='User'): ?>
            <?php $__currentLoopData = $getlivemsgdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($s->sender == "Admin"): ?>
                    <li class="left clearfix">
                     <span style="color: red" class="chat-img1 pull-left">Admin
                     </span>

                        <div class="chat-body1 clearfix ">
                            <div ><?php echo e($s->inserted_time); ?></div><br>
                            <p ><?php echo e($s->sms); ?></p>

                        </div>
                    </li>
                <?php else: ?>

                    <li class="left clearfix admin_chat"><?php echo e($s->sender); ?>

                     <span style="color: blue"class="chat-img1 pull-right"><?php echo e($client1); ?>

                     </span>

                        <div class="chat-body1 clearfix">
                            <div class="pull-right"><?php echo e($s->inserted_time); ?></div><br>
                            <p class="pull-right"><?php echo e($s->sms); ?></p>

                        </div>
                    </li>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>

    </ul>


</div>

